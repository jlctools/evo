// Evo C++ Library
/* Copyright (c) 2015 Justin Crowell
 This Source Code Form is subject to the terms of the Mozilla Public
 License, v. 2.0. If a copy of the MPL was not distributed with this
 file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/
///////////////////////////////////////////////////////////////////////////////
/** \file sys.h Evo implementation detail: System portability handling. */
#pragma once
#ifndef INCL_evo_impl_sys_h
#define INCL_evo_impl_sys_h

// Includes - System Specific
#if defined(__linux) || defined(__CYGWIN__)
	#include <unistd.h>
	#include <errno.h>
	#if defined(__linux)
		#include <stdint.h>
	#endif
#elif defined(_WIN32)
#else
	#error "This system is not supported by Evo"
#endif

// Includes - System
#include <stdlib.h>
#include <stdio.h>
#include <limits>
#include <limits.h>
#include <float.h>
#include <math.h>
#include <string.h>
#include <assert.h>

/** \addtogroup EvoLibrary */
//@{
///////////////////////////////////////////////////////////////////////////////
/** \cond impl */

// 64 bit environment
#if defined(__LP64__) || defined(_LP64) || defined(_WIN64)
	#define EVO_64 1
#else
	#define EVO_32 1
#endif

// Primitive aliases
typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long long int ulongl;
typedef long long int longl;
typedef long double ldouble;

#if defined(_WIN32)
	typedef unsigned int uint;
	typedef unsigned long ulong;
	typedef __int8  int8;
	typedef __int16 int16;
	typedef __int32 int32;
	typedef __int64 int64;
	typedef unsigned __int8  uint8;
	typedef unsigned __int16 uint16;
	typedef unsigned __int32 uint32;
	typedef unsigned __int64 uint64;
#else
	typedef int8_t  int8;
	typedef int16_t int16;
	typedef int32_t int32;
	typedef int64_t int64;
	typedef uint8_t  uint8;
	typedef uint16_t uint16;
	typedef uint32_t uint32;
	typedef uint64_t uint64;
#endif

// Used to ignore certain warnings
#if defined(_MSC_VER)
	#define EVO_PARAM_UNUSED(NAME)       __pragma(warning(suppress:4100)) NAME
	#define EVO_MSVC_NOWARN_START(CODES) __pragma(warning(push)) __pragma(warning(disable:CODES))
	#define EVO_MSVC_NOWARN_END          __pragma(warning(pop))
#else
	#define EVO_PARAM_UNUSED(NAME)
	#define EVO_MSVC_NOWARN_START(CODE)
	#define EVO_MSVC_NOWARN_END
#endif

/** \endcond */
///////////////////////////////////////////////////////////////////////////////

/** Shortcut for NULL as const-char pointer. */
#define EVO_CNULL ((const char*)0)

/** Shortcut for NULL as void-pointer. */
#define EVO_VNULL ((void*)0)

///////////////////////////////////////////////////////////////////////////////

// Floating point functions
/** \cond impl */

// Windows -- has overloads for all floating point types
#if defined _WIN32
	#define evo_pow pow
	#define evo_modf modf
	#define evo_fabs fabs

// Unix/Linux -- has separate functions for float and long-double
#else
	// Determine whether long double math functions are supported
	#if defined(__CYGWIN__)
		// This indicates a possible precision loss on long-double due to missing math functions
		#define EVO_LDBL_NOMATH
	#endif

	// evo_pow()
	inline float evo_pow(float x, float y)
		{ return powf(x, y); }
	inline double evo_pow(double x, double y)
		{ return pow(x, y); }
	#if defined EVO_LDBL_NOMATH
		// Use pow() -- possible precision loss
		inline long double evo_pow(long double x, long double y)
			{ return pow((double)x, (double)y); }
	#else
		inline long double evo_pow(long double x, long double y)
			{ return powl(x, y); }
	#endif

	// evo_modf()
	inline float evo_modf(float x, float* iptr)
		{ return modff(x, iptr); }
	inline double evo_modf(double x, double* iptr)
		{ return modf(x, iptr); }
	#if defined EVO_LDBL_NOMATH
		// Use modf() -- possible precision loss
		inline long double evo_modf(long double x, long double* iptr)
			{ return modf((double)x, (double*)iptr); }
	#else
		inline long double evo_modf(long double x, long double* iptr)
			{ return modfl(x, iptr); }
	#endif

	// evo_fabs()
	inline float evo_fabs(float x)
		{ return fabsf(x); }
	inline double evo_fabs(double x)
		{ return fabs(x); }
	#if defined EVO_LDBL_NOMATH
		inline long double evo_fabs(long double x)
			{ return (x<0.0 ? -x : x); }
	#else
		inline long double evo_fabs(long double x)
			{ return fabsl(x); }
	#endif

#endif
/** \endcond */

///////////////////////////////////////////////////////////////////////////////

// Namespace: evo
namespace evo {

///////////////////////////////////////////////////////////////////////////////

/** Null value type */
enum ValNull {
	vNull=0		///< Null value
};

/** Empty value type */
enum ValEmpty {
	vEmpty=0	///< Empty value
};

/** Value type to specify reverse algorithm. */
enum ValAlgReverse {
	vReverse=0	///< Value to reverse algorithm
};

///////////////////////////////////////////////////////////////////////////////

/** General error code. This is used when exceptions are too expensive or don't apply. */
enum Error {
	ENone = 0,			///< No error
	EInval,				///< Invalid operation or data error
	EOutOfBounds		///< Out of bounds error
};

///////////////////////////////////////////////////////////////////////////////

/** Evo base exception. */
class Exception {
public:
	/** Constructor. Use THROW() or THROW_T() macro to throw exception.
	 \param  msg  Exception message string (null terminated).
	*/
	Exception(const char* msg) : _file("???"), _line(0), _msg(NULL)
		{ setMsg(msg); }
	/** Constructor. Use THROW() or THROW_T() macro to throw exception.
	 \param  file  Exception file name.
	 \param  line  Exception line number.
	 \param  msg   Exception message.
	*/
	Exception(const char* file, ulong line, const char* msg) : _file(file), _line(line), _msg(NULL)
		{ setMsg(msg); }
	/** Copy constructor.
	 \param  e  Exception to copy.
	*/
	Exception(const Exception& e) : _file(e._file), _line(e._line), _msg(NULL)
		{ setMsg(e._msg); }
	/** Destructor */
	~Exception() { if (_msg != NULL) free(_msg); }

	/** Get exception file name.
	 \return  File name.
	*/
	const char* file() const { return _file; }

	/** Get exception line number.
	 \return  Line number.
	*/
	ulong line() const { return _line; }

	/** Get exception message.
	 \return  Message.
	*/
	const char* msg() const { return (_msg == NULL) ? "" : _msg; }

private:
	const char* _file;		///< File name
	ulong       _line;		///< Line number
	char*       _msg;		///< Message

	void setMsg(const char* msg) {
		ulong msgLen = strlen(msg);
		if (msgLen > 0) {
			_msg = (char*)malloc(msgLen+1);
			memcpy(_msg, msg, msgLen);
			_msg[msgLen] = '\0';
		}
	}
};

/** Invalid operation or data exception. Used when an invalid operation is attempted or invalid input data is used. */
struct ExceptionInval : public Exception {
	ExceptionInval(const char* msg) : Exception(msg) { }
	ExceptionInval(const char* file, ulong line, const char* msg) : Exception(file, line, msg) { }
	ExceptionInval(const ExceptionInval& e) : Exception(e) { }
};

/** Out of bounds exception. Used when a value or index is out of bounds. */
struct ExceptionOutOfBounds : public Exception {
	ExceptionOutOfBounds(const char* msg) : Exception(msg) { }
	ExceptionOutOfBounds(const char* file, ulong line, const char* msg) : Exception(file, line, msg) { }
	ExceptionOutOfBounds(const ExceptionOutOfBounds& e) : Exception(e) { }
};

/** Allocation exception. Used when an operation is invalid or incompatible with allocator used. */
struct ExceptionAlloc : public Exception {
	ExceptionAlloc(const char* msg) : Exception(msg) { }
	ExceptionAlloc(const char* file, ulong line, const char* msg) : Exception(file, line, msg) { }
	ExceptionAlloc(const ExceptionAlloc& e) : Exception(e) { }
};

/** Throws general exception with file/line info.
 \param  msg  Exception message string (const char*).
*/
#define THROW(msg) throw evo::Exception(__FILE__, __LINE__, msg)

/** Throws specified exception derived from Exception with file/line info.
 \param  type  Exception type (should be Exception or derived from it).
 \param  msg   Exception message string (const char*).
*/
#define THROW_T(type,msg) throw type(__FILE__, __LINE__, msg)

///////////////////////////////////////////////////////////////////////////////
} // Namespace: evo
//@}
#endif
