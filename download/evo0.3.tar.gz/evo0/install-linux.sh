#!/bin/bash
# Quick script to install Evo on Linux systems

installpath=/opt/evo0
symlinkdir=/usr/local/include
if [[ $# > 1 || "$1" == "-h" || "$1" == "--help" ]]; then
	echo "Usage: $0 [PATH]"
	echo ""
	echo "Install Evo library at PATH -- default: /opt/evo0"
	exit 1
fi
if [[ $# > 0 ]]; then
	installpath="$1"
fi

echo "Installing Evo: '$installpath'"
if ! mkdir -vp "$installpath"; then
	echo "Failed to create dir '$installpath' -- may need to run as root (sudo)"
	exit 1
fi
if ! mkdir -vp "$symlinkdir"; then
	echo "Failed to create dir '$symlinkdir' -- may need to run as root (sudo)"
	exit 1
fi

echo "Copying files..."
if ! cp -r doc include *.txt "$installpath"; then
	echo "Failed to copy files -- may need to run as root (sudo)"
	exit 1
fi

echo "Setting permissions... (0755)"
if ! chmod -R 0755 "$installpath"; then
	echo "WARNING: Failed to set permissions -- may need to run as root (sudo)"
fi

symlinkpath=$symlinkdir/evo
echo "Creating symlink: '$symlinkpath' -> '$installpath/include/evo'"
if [[ -L "$symlinkpath" ]]; then
	rm -f "$symlinkpath"
fi
if [[ ! -e "$symlinkpath" ]]; then
	if ! ln -s "$installpath/include/evo" "$symlinkpath"; then
		echo "Failed creating symlinks -- may need to run as root (sudo)"
		exit 1
	fi
else
	echo "Symlink already exists:"
	ls -la "$symlinkpath"
fi

# Update include/evo/README.txt with install path
sed -i "s|/opt/evo0/|$installpath/|g" "$installpath/include/evo/README.txt"

echo "Done"
exit 0

